#ifndef SERVER_H
#define SERVER_H

#include "network.h"   // BUFSIZE, PORT

#include <pthread.h>

typedef struct Client {
    int sock;
    struct Client *next;
} Client;

extern Client *clients;
extern pthread_mutex_t clients_mutex;
extern pthread_mutex_t buf_mutex;

void add_client(int sock);
void remove_client(int sock);
void broadcast(const char *msg);

#endif

