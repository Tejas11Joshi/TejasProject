#ifndef NETWORK_H
#define NETWORK_H

#define MAX_CLIENTS 32
#define BUFSIZE 8192
#define PORT 12345

#endif